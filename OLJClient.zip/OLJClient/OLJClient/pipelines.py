import csv

from scrapy.exporters import CsvItemExporter


class SortingCsvItemExporter(CsvItemExporter):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.items = []

    def finish_exporting(self):
        self.items.sort(key=lambda item: item["Scrape Id"])
        for item in self.items:
            self._write_item(item.decode("utf-8"))

    def _write_headers(self):
        headers = self._get_serialized_fields()
        self.csv_writer.writerow(headers.decode("utf-8"))

    def _write_item(self, item):
        self.items.append(item.decode("utf-8"))

class MyPipeline:
    def open_spider(self, spider):
        self.file = open("items.csv", "w")
        self.exporter = SortingCsvItemExporter(self.file)
        self.exporter.start_exporting()

    def close_spider(self, spider):
        self.exporter.finish_exporting()
        self.file.close()

    def process_item(self, item, spider):
        #self.exporter.export_item(item)
        return item
