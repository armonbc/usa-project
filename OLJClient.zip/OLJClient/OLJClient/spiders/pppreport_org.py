import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
from scrapy import Request
import re
import time

class PppreportOrgSpider(CrawlSpider):
    name = 'pppreport_org'
    allowed_domains = ['pppreport.org','www.pppreport.org']
    
    rules = (
        Rule(LinkExtractor(allow='/location',restrict_xpaths=('.//table[@class="table"]//a')), follow=True),
        Rule(LinkExtractor(allow='/company/',restrict_xpaths=('.//table[@id="myTable"]//a')), callback='parse_all', follow=True),
    )

    def __init__(self, url='', *args, **kwargs):
        self.start_urls=[]
        self.start_urls.append(url)
        super(PppreportOrgSpider, self).__init__(*args, **kwargs)

    def start_requests(self):
        for url in self.start_urls:
            yield Request(url)

    def parse_all(self,response):
        self.logger.debug("\n\n Current Company Url => "+response.url+"\n\n")
        for post in response.xpath('//table'):
            yield{
                'Business Name': self.get_business_name(response=post),
                'State':self.get_state(response=post),
                'City':self.get_city(response=post),
                'Address':self.get_address(response=post),
                'Jobs Retained': self.get_jobs_retained(response=post),
                'Date Approved': self.get_date_approved(response=post)
        }

    #Function name to business name using xpath payload
    def get_business_name(self,response):
        business_name = ''.join(response.xpath('.//td[1][contains(text(), "Business Name as Filed")]/../td[2]/text()').extract()).strip()
        return self.sanitize(business_name)

    #Function name to state name using xpath payload
    def get_state(self,response):
        state = ''.join(response.xpath('.//ol[@class="breadcrumb"]//text()').extract()).strip().replace("\n\n\n›\n\n\n",", ")
        pattern = r'^[^,]*,\s*(\b\w+\b)'
        match = re.search(pattern, state)
        if match:
            return self.sanitize(match.group(0))
        return self.sanitize(state)

    #Function name to city name using xpath payload
    def get_city(self,response):
        city = ''.join(response.xpath('.//ol[@class="breadcrumb"]//text()').extract()).strip().replace("\n\n\n›\n\n\n",", ")
        pattern = r'^[^,]*,\s*[^,]*,\s*([^,]*),'
        match = re.search(pattern, city)
        if match:
            return self.sanitize(match.group(0))
        return self.sanitize(city)

    #Function name to capture address using xpath payload
    def get_address(self,response):
        address = ''.join(response.xpath('.//td[1][contains(text(), "Address")]/../td[2]//text()').extract()).strip()
        return self.sanitize(address)

    #Function name to parse jobs retained using xpath payload
    def get_jobs_retained(self,response):
        jobs_retained = ''.join(response.xpath('.//td[1][contains(text(), "Jobs Retained")]/../td[2]/text()').extract()).strip()
        return self.sanitize(jobs_retained)

    #Function name to parse interior size
    def get_date_approved(self,response):
        date_approved = ''.join(response.xpath('.//td[1][contains(text(), "Date Approved")]/../td[2]/text()').extract()).strip()
        return self.sanitize(date_approved)

    #Function name to prevent returning NoneType
    def sanitize(self,value):
        if isinstance(value,re.Match):
            return value.group(0)
        if not value or None:
            return "Not Found"
        return value

'''
["Instruction 1 of 1"]
** 1.) To scrape all tha data, use the following command:

scrapy crawl 'pppreport_org' -O 'pppreport_org.csv' -a "url=https://pppreport.org/location/"



** 2.) To test scrape up to 50 pages, use the following command:

scrapy crawl 'pppreport_org' -s CLOSESPIDER_PAGECOUNT=100 -O 'pppreport_org.csv' -a "url=https://pppreport.org/location/"


** Note:
* You CAN change the csv filename from 'pppreport_org.csv' to 'anyname.csv'
* You CANNOT CHANGE the spider name 'pppreport_org' not unless you edit the same in the 'name' variable above
'''
